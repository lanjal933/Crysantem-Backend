require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const path = require('path');
const config = require('./config/config');
const { generalLimiter } = require('./middleware/rateLimiter');

const app = express();

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "https://accounts.google.com", "https://oauth2.googleapis.com", "https://www.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      mediaSrc: ["'self'"],
    },
  },
}));

app.use(cors({
  origin: config.cors.allowedOrigins,
  credentials: true,
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// Servir archivos estáticos antes del rate limiter
if (config.serveFrontend) {
  // Servir archivos HTML específicos directamente
  app.get('*.html', (req, res) => {
    const filePath = path.join(__dirname, '../frontend', req.path);
    if (require('fs').existsSync(filePath)) {
      console.log('Sirviendo archivo HTML:', req.path);
      return res.sendFile(filePath);
    }
    console.log('Archivo HTML no encontrado, sirviendo index.html:', req.path);
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
  });
  
  // Servir otros archivos estáticos
  app.use(express.static(path.join(__dirname, '../frontend')));
}

// Aplicar rate limiter solo a rutas API
app.use('/api', generalLimiter);

app.use('/api/auth', require('./routes/auth'));
app.use('/api/ai', require('./routes/ai'));
app.use('/api/config', require('./routes/config'));
app.use('/api/myia', require('./routes/myia'));

// Ruta catch-all para SPA (después de las rutas API)
if (config.serveFrontend) {
  app.get('*', (req, res) => {
    // NO servir archivos HTML aquí (ya se manejan arriba)
    // Solo servir index.html para rutas que no son archivos
    if (!req.path.endsWith('.html') && !req.path.includes('.')) {
      res.sendFile(path.join(__dirname, '../frontend/index.html'));
    } else {
      // Para archivos que no son HTML (como imágenes, CSS, JS)
      const filePath = path.join(__dirname, '../frontend', req.path);
      if (require('fs').existsSync(filePath)) {
        return res.sendFile(filePath);
      }
      res.sendFile(path.join(__dirname, '../frontend/index.html'));
    }
  });
}

app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({ error: 'Error interno del servidor' });
});

const PORT = config.port;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en puerto ${PORT}`);
  console.log(`Ambiente: ${config.nodeEnv}`);
  if (config.serveFrontend) {
    console.log(`Frontend servido desde: ${path.join(__dirname, '../frontend')}`);
  }
});
