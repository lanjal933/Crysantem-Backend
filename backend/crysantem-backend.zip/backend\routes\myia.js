const express = require('express');
const router = express.Router();
const { createClient } = require('@supabase/supabase-js');
const { generalLimiter } = require('../middleware/rateLimiter');
const { myiaConfigValidation } = require('../middleware/validator');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

// Configuración de webhooks por plan (PRODUCTION)
const PLAN_WEBHOOKS = {
  responde: process.env.WEBHOOK_RESPONDE,
  asiste: process.env.WEBHOOK_ASISTE,
  automatiza: process.env.WEBHOOK_AUTOMATIZA,
  intelligence: process.env.WEBHOOK_INTELLIGENCE
};

// Eliminar página (borrado completo de la base de datos)
router.delete('/delete/:id', generalLimiter, async (req, res) => {
  try {
    const { id } = req.params;

    console.log('Eliminando página con ID:', id);

    // Eliminar de myia_page_config
    const { error: configError } = await supabase
      .from('myia_page_config')
      .delete()
      .eq('id', id);

    if (configError) {
      console.error('Error al eliminar config:', configError);
      return res.status(500).json({ success: false, error: configError.message });
    }

    console.log('Página eliminada exitosamente:', id);

    res.json({ success: true, message: 'Página eliminada exitosamente' });
  } catch (error) {
    console.error('Error deleting page:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Proxy para mensajes de chat a n8n (seguro - webhooks solo en backend)
router.post('/chat-message', generalLimiter, async (req, res) => {
  try {
    const { message, pageId, userId, plan } = req.body;

    console.log('=== MENSAJE DE CHAT RECIBIDO ===');
    console.log('Timestamp:', new Date().toISOString());
    console.log('Page ID:', pageId);
    console.log('User ID:', userId);
    console.log('Plan:', plan);
    console.log('Message:', message);

    // Obtener configuración de la página para obtener el slug
    const { data: pageConfig, error: configError } = await supabase
      .from('myia_page_config')
      .select('business_name, slug, system_prompt, plan')
      .eq('id', pageId)
      .single();

    if (configError || !pageConfig) {
      console.error('Error al obtener configuración de página:', configError);
      return res.status(404).json({ success: false, error: 'Página no encontrada' });
    }

    // Obtener webhook URL según el plan (solo en backend)
    const webhookUrl = PLAN_WEBHOOKS[plan] || PLAN_WEBHOOKS.responde;
    console.log('Enviando a webhook del plan:', plan);
    console.log('Slug para n8n:', pageConfig.slug);

    // Enviar mensaje a n8n con el formato correcto y firma HMAC
    const axios = require('axios');
    const crypto = require('crypto');
    const config = require('../config/config');

    const timestamp = Math.floor(Date.now() / 1000);
    const payload = JSON.stringify({
      slug: pageConfig.slug,
      chatInput: message
    });

    const signature = crypto
      .createHmac('sha256', config.security.n8nWebhookSecret)
      .update(timestamp + payload)
      .digest('hex');

    const response = await axios.post(webhookUrl, {
      slug: pageConfig.slug,          // Para que Supabase filtre y obtenga el system_prompt
      chatInput: message             // Coincide con la expresión {{ $('agente-workspace').first().json.chatInput }}
    }, {
      headers: {
        'Content-Type': 'application/json',
        'X-Webhook-Signature': signature,
        'X-Webhook-Timestamp': timestamp.toString()
      },
      timeout: 30000 // 30 segundos timeout
    });

    console.log('Respuesta de n8n recibida:', response.status);

    res.json({
      success: true,
      response: response.data.response || response.data.message || response.data.output || response.data || 'Respuesta recibida'
    });
  } catch (error) {
    console.error('Error procesando mensaje de chat:', error.message);
    console.error('Error completo:', error);
    res.status(500).json({
      success: false,
      error: 'Error al procesar el mensaje. Verifica que los webhooks de n8n estén configurados correctamente.'
    });
  }
});

// Guardar configuración de página
router.post('/config', generalLimiter, myiaConfigValidation, async (req, res) => {
  const fs = require('fs');
  const path = require('path');
  const logFile = path.join(__dirname, '../debug-config.log');
  
  const log = (message) => {
    console.log(message);
    fs.appendFileSync(logFile, `${new Date().toISOString()} - ${message}\n`);
  };
  
  try {
    const { userId, config } = req.body;
    
    log('=== DATOS RECIBIDOS ===');
    log('userId: ' + userId);
    log('config.integrations_config: ' + JSON.stringify(config.integrations_config));
    log('config.payment_plan: ' + config.payment_plan);
    log('config.payment_method: ' + config.payment_method);
    log('config.google_connected: ' + config.google_connected);

    // Asegurar que el usuario exista en myia_users
    const { data: myiaUser } = await supabase
      .from('myia_users')
      .select('id')
      .eq('id', userId)
      .single();

    if (!myiaUser) {
      const { data: mainUser } = await supabase
        .from('users')
        .select('email')
        .eq('id', userId)
        .single();

      if (mainUser) {
        await supabase.from('myia_users').insert({
          id: userId,
          email: mainUser.email,
          scopes: ['email', 'profile']
        });
        console.log('Usuario creado en myia_users:', userId);
      } else {
        return res.status(400).json({ success: false, error: 'Usuario no encontrado' });
      }
    }

    // Verificar si ya existe configuración con el mismo slug
    if (config.slug) {
      const { data: existingSlug } = await supabase
        .from('myia_page_config')
        .select('id')
        .eq('slug', config.slug)
        .single();

      if (existingSlug && (!config.id || existingSlug.id !== config.id)) {
        return res.status(400).json({ success: false, error: 'El slug ya está en uso' });
      }
    }

    // Verificar si ya existe configuración para este usuario
    const { data: existing } = await supabase
      .from('myia_page_config')
      .select('*')
      .eq('user_id', userId)
      .eq('id', config.id || '')
      .single();

    let result;
    let firstInsertError = null;
    let updateError = null;

    // Intento 1: Con todas las columnas
    const fullUpdateData = {
      business_name: config.business_name,
      slug: config.slug,
      logo_url: config.logo_url,
      logo_size: config.logo_size,
      background_type: config.background_type,
      background_color: config.background_color,
      background_gradient: config.background_gradient,
      glow_color: config.glow_color,
      font_family: config.font_family,
      title_font: config.title_font,
      chat_box_design: config.chat_box_design,
      chat_position: config.chat_position,
      border_radius: config.border_radius,
      chat_box_color: config.chat_box_color,
      header_theme: config.header_theme,
      page_design: config.page_design,
      show_footer: config.show_footer,
      split_image: config.split_image,
      split_text: config.split_text,
      welcome_message: config.welcome_message,
      system_prompt: config.system_prompt,
      ai_model: config.ai_model,
      character_limit: config.character_limit,
      plan: config.plan,
      social_links: config.social_links,
      is_active: config.is_active,
      integrations_config: config.integrations_config || null,
      payment_plan: config.payment_plan || null,
      payment_method: config.payment_method || null,
      google_connected: config.google_connected || false,
      super_prompt: config.super_prompt || null
    };

    // Intento 2: Solo columnas básicas (CON INTEGRACIONES)
    const basicUpdateData = {
      business_name: config.business_name,
      slug: config.slug,
      logo_url: config.logo_url,
      logo_size: config.logo_size,
      background_type: config.background_type,
      background_color: config.background_color,
      font_family: config.font_family,
      chat_position: config.chat_position,
      border_radius: config.border_radius,
      chat_box_color: config.chat_box_color,
      header_theme: config.header_theme,
      welcome_message: config.welcome_message,
      system_prompt: config.system_prompt,
      ai_model: config.ai_model,
      character_limit: config.character_limit,
      plan: config.plan,
      social_links: config.social_links,
      is_active: config.is_active,
      integrations_config: config.integrations_config || null,
      payment_plan: config.payment_plan || null,
      payment_method: config.payment_method || null,
      google_connected: config.google_connected || false,
      super_prompt: config.super_prompt || null
    };

    try {
      if (existing && config.id) {
        const { data, error } = await supabase
          .from('myia_page_config')
          .update(fullUpdateData)
          .eq('id', config.id)
          .select()
          .single();

        if (error) {
          firstInsertError = error;
          throw error;
        }
        result = data;
      } else {
        const { data, error } = await supabase
          .from('myia_page_config')
          .insert({
            user_id: userId,
            ...fullUpdateData
          })
          .select()
          .single();

        if (error) {
          firstInsertError = error;
          throw error;
        }
        result = data;
      }
    } catch (error) {
      log('=== ERROR EN PRIMER INTENTO ===');
      log('Error message: ' + error.message);
      log('Error code: ' + error.code);
      log('Error details: ' + error.details);
      log('Intentando con columnas básicas...');

      if (existing && config.id) {
        const { data, error } = await supabase
          .from('myia_page_config')
          .update(basicUpdateData)
          .eq('id', config.id)
          .select()
          .single();

        if (error) {
          log('=== ERROR EN SEGUNDO INTENTO ===');
          log('Error: ' + JSON.stringify(error));
          throw error;
        }
        result = data;
      } else {
        const { data, error } = await supabase
          .from('myia_page_config')
          .insert({
            user_id: userId,
            ...basicUpdateData
          })
          .select()
          .single();

        if (error) {
          log('=== ERROR EN SEGUNDO INTENTO ===');
          log('Error: ' + JSON.stringify(error));
          throw error;
        }
        result = data;
      }
    }
    
    // ACTUALIZAR INTEGRACIONES POR SEPARADO (FUERA DEL TRY/CATCH PARA QUE SIEMPRE SE EJECUTE)
    if (result && result.id) {
      log('=== ACTUALIZANDO INTEGRACIONES POR SEPARADO ===');
      log('ID del registro: ' + result.id);
      log('Datos a actualizar: ' + JSON.stringify({
        integrations_config: config.integrations_config,
        payment_plan: config.payment_plan,
        payment_method: config.payment_method,
        google_connected: config.google_connected
      }));
      
      const { data: updateResult, error: updateError } = await supabase
        .from('myia_page_config')
        .update({
          integrations_config: config.integrations_config || null,
          payment_plan: config.payment_plan || null,
          payment_method: config.payment_method || null,
          google_connected: config.google_connected || false
        })
        .eq('id', result.id)
        .select()
        .single();
      
      log('Resultado del update: ' + JSON.stringify(updateResult));
      log('Error del update: ' + (updateError ? JSON.stringify(updateError) : 'null'));
      
      if (!updateError) {
        result = updateResult;
        log('Update exitoso');
      } else {
        log('=== UPDATE DE INTEGRACIONES FALLÓ ===');
        log('Error: ' + JSON.stringify(updateError));
      }
    }

    res.json({ 
      success: true, 
      data: result,
      update_error: updateError ? updateError.message : null
    });
  } catch (error) {
    console.error('Error saving config:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Obtener todas las apps de un usuario
router.get('/user-apps/:userId', async (req, res) => {
  try {
    const { userId } = req.params;

    const { data, error } = await supabase
      .from('myia_page_config')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;

    res.json({ success: true, data });
  } catch (error) {
    console.error('Error getting user apps:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Obtener configuración por ID
router.get('/config-by-id/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const { data, error } = await supabase
      .from('myia_page_config')
      .select('*')
      .eq('id', id)
      .single();

    if (error) throw error;

    res.json({ success: true, data });
  } catch (error) {
    console.error('Error getting config by id:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Servir página HTML por slug (pública)
router.get('/render/:slug', async (req, res) => {
  try {
    const { slug } = req.params;
    console.log('Renderizando página con slug:', slug);

    const { data, error } = await supabase
      .from('myia_page_config')
      .select('*')
      .eq('slug', slug)
      .eq('is_active', true)
      .single();

    if (error) {
      console.error('Error al buscar página:', error);
      return res.status(404).send('Página no encontrada o no está activa');
    }

    if (!data) {
      console.log('Página no encontrada para slug:', slug);
      return res.status(404).send('Página no encontrada o no está activa');
    }

    console.log('Configuración encontrada:', {
      business_name: data.business_name,
      slug: data.slug,
      is_active: data.is_active
    });

    const html = generatePageHTML(data);
    res.send(html);
  } catch (error) {
    console.error('Error rendering page:', error);
    res.status(500).send('Error al renderizar la página: ' + error.message);
  }
});

function generatePageHTML(config, webhookUrl) {
  const titleFont = config.title_font || config.font_family;
  const socialLinks = config.social_links || {};
  const socialLinksHTML = Object.entries(socialLinks).map(([network, url]) => {
    if (!url) return '';
    const icons = { facebook: 'FB', instagram: 'IG', linkedin: 'LI', twitter: 'TW' };
    return `<a href="${url}" target="_blank" style="color: white; text-decoration: none; margin: 0 10px; padding: 8px 16px; background: rgba(255,255,255,0.1); border-radius: 20px; font-size: 0.85rem;">${icons[network] || network}</a>`;
  }).join('');

  const getBackground = () => {
    if (config.background_type === 'gradient' && config.background_gradient) {
      return `linear-gradient(135deg, ${config.background_color} 0%, ${config.background_gradient} 100%)`;
    }
    if (config.background_type === 'glow' && config.glow_color) {
      return `radial-gradient(ellipse at top right, ${config.glow_color}33 0%, transparent 50%), ${config.background_color}`;
    }
    return config.background_color || '#050505';
  };

  const getBorderRadius = () => {
    if (config.border_radius === 'sharp') return '0px';
    if (config.border_radius === 'pill') return '24px';
    return '12px';
  };

  const getChatStyle = () => {
    if (config.chat_box_design === 'classic') return `background: rgba(245, 245, 245, 0.95); color: #1a1a1a; border: 2px solid ${config.chat_box_color};`;
    if (config.chat_box_design === 'minimal') return `background: transparent; color: white; border: 1px solid rgba(255,255,255,0.3);`;
    if (config.chat_box_design === 'neon') return `background: ${config.chat_box_color}30; color: white; border: 1px solid ${config.chat_box_color}50; box-shadow: 0 0 15px ${config.chat_box_color}40;`;
    if (config.chat_box_design === 'glass') return `background: rgba(255,255,255,0.1); color: white; backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.2);`;
    return `background: ${config.chat_box_color}20; color: white;`;
  };

  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https: http:; connect-src 'self' https://cdn.jsdelivr.net;">
  <title>${config.business_name || 'Agente IA'}</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { background: ${getBackground()}; font-family: ${config.font_family || 'Inter'}; color: white; min-height: 100vh; }
    .container { min-height: 100vh; display: flex; flex-direction: column; padding: 40px; }
    .header { width: 100%; max-width: 800px; margin: 0 auto 40px; border-radius: 0; background: ${config.header_color || 'rgba(0,0,0,0.3)'}; display: flex; align-items: center; gap: 20px; padding: 20px; }
    .logo { width: ${config.logo_size || 100}px; height: ${config.logo_size || 100}px; object-fit: contain; border-radius: 8px; }
    h1 { font-family: ${titleFont}; font-size: ${config.header_title_size || '2rem'}; font-weight: 700; }
    .content { flex: 1; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; max-width: 800px; margin: 0 auto; }
    .chat-section { padding: 40px; background: rgba(0,0,0,0.1); border-radius: 12px; width: 100%; }
    .chat-wrapper { max-width: 600px; margin: 0 auto; width: 100%; }
    .chat { background: rgba(0,0,0,0.8); border-radius: ${getBorderRadius()}; overflow: hidden; ${getChatStyle()} box-shadow: 0 10px 40px rgba(0,0,0,0.3); }
    .chat-header { padding: 20px; font-weight: 600; font-size: 1.1rem; border-bottom: 1px solid rgba(255,255,255,0.1); display: flex; align-items: center; gap: 12px; }
    .chat-status { width: 10px; height: 10px; background: #00ff8c; border-radius: 50%; }
    .chat-messages { padding: 20px; max-height: 400px; overflow-y: auto; min-height: 300px; }
    .chat-bubble { padding: 14px 18px; border-radius: ${getBorderRadius()}; margin-bottom: 16px; max-width: 85%; line-height: 1.5; }
    .chat-bubble.ai { background: ${config.chat_box_color}40; margin-right: auto; }
    .chat-bubble.user { background: rgba(255,255,255,0.1); margin-left: auto; }
    .chat-input { padding: 16px; border-top: 1px solid rgba(255,255,255,0.1); display: flex; gap: 12px; }
    .chat-input input { flex: 1; padding: 12px 16px; background: rgba(255,255,255,0.1); border: none; border-radius: 20px; color: white; font-size: 0.95rem; }
    .chat-input input::placeholder { color: rgba(255,255,255,0.5); }
    .chat-input button { padding: 12px 20px; background: ${config.chat_box_color}; border: none; border-radius: 20px; color: black; font-weight: 600; cursor: pointer; }
    .chat-input button:hover { opacity: 0.9; }
    .footer { margin-top: 20px; padding: 20px; text-align: center; font-size: 0.85rem; color: rgba(255,255,255,0.5); border-top: 1px solid rgba(255,255,255,0.1); }
    .social-links { margin-top: 16px; display: flex; justify-content: center; gap: 8px; }

    /* Navbar styles */
    .navbar { position: fixed; top: 0; left: 0; right: 0; background: rgba(5, 5, 5, 0.9); backdrop-filter: blur(10px); border-bottom: 1px solid rgba(255, 255, 255, 0.1); z-index: 1000; padding: 15px 40px; }
    .navbar-content { display: flex; justify-content: space-between; align-items: center; max-width: 1200px; margin: 0 auto; }
    .navbar-logo { display: flex; align-items: center; gap: 10px; text-decoration: none; color: white; font-weight: 600; }
    .navbar-logo-img { height: 30px; }
    .navbar-auth { position: relative; }
    .navbar-auth-btn { background: transparent; color: rgba(255, 255, 255, 0.7); font-size: 0.9rem; padding: 8px 16px; border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 4px; transition: all 0.3s ease; cursor: pointer; }
    .navbar-auth-btn:hover { color: white; border-color: rgba(255, 255, 255, 0.2); }
    .navbar-dropdown { position: absolute; top: 100%; right: 0; margin-top: 8px; background: rgba(16, 16, 16, 0.95); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 8px; padding: 8px; min-width: 180px; opacity: 0; visibility: hidden; transform: translateY(-10px); transition: all 0.3s ease; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5); }
    .navbar-dropdown.active { opacity: 1; visibility: visible; transform: translateY(0); }
    .navbar-dropdown-item { display: block; width: 100%; text-align: left; padding: 8px 16px; color: rgba(255, 255, 255, 0.7); font-size: 0.9rem; border-radius: 4px; transition: all 0.3s ease; background: none; border: none; cursor: pointer; }
    .navbar-dropdown-item:hover { background: rgba(0, 255, 140, 0.1); color: #00ff8c; }
    .navbar-dropdown-logout { color: #ff4444 !important; }
    .navbar-dropdown-logout:hover { background: rgba(255, 68, 68, 0.1) !important; color: #ff4444 !important; }

    /* Modal styles */
    .modal { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0, 0, 0, 0.8); align-items: center; justify-content: center; padding: 20px; z-index: 2000; }
    .modal.active { display: flex; }
    .modal-content { background: rgba(16, 16, 16, 0.95); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 16px; padding: 32px; max-width: 450px; width: 100%; max-height: 90vh; overflow-y: auto; box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4); }
    .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
    .modal-title { font-size: 1.5rem; font-weight: 700; color: white; }
    .modal-close { background: none; color: rgba(255, 255, 255, 0.5); font-size: 1.5rem; padding: 8px; transition: color 0.3s ease; border: none; cursor: pointer; }
    .modal-close:hover { color: #00ff8c; }
    .form-group { margin-bottom: 16px; }
    .form-group label { display: block; margin-bottom: 8px; color: rgba(255, 255, 255, 0.7); font-size: 0.9rem; }
    .form-group input { width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 8px; color: white; font-size: 0.95rem; transition: all 0.3s ease; }
    .form-group input:focus { outline: none; border-color: #00ff8c; background: rgba(255, 255, 255, 0.1); }
    .form-group input::placeholder { color: rgba(255, 255, 255, 0.3); }
    .form-error { color: #ff4444; font-size: 0.85rem; margin-top: 4px; display: none; }
    .btn { padding: 12px 24px; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; font-size: 0.95rem; }
    .btn-primary { background: #00ff8c; color: black; }
    .btn-primary:hover { background: #00e67a; transform: translateY(-1px); }
    .btn-full { width: 100%; }
    .auth-tabs { display: flex; gap: 8px; margin-bottom: 20px; }
    .auth-tab { flex: 1; padding: 10px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 8px; color: rgba(255, 255, 255, 0.7); cursor: pointer; transition: all 0.3s ease; font-size: 0.85rem; }
    .auth-tab.active { background: rgba(0, 255, 140, 0.1); border-color: #00ff8c; color: #00ff8c; }
    .auth-tab-content { display: none; }
    .auth-tab-content:first-child { display: block; }

    @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    @keyframes slideOut { from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; } }
  </style>
</head>
<body>
  <nav class="navbar">
    <div class="navbar-content">
      <a href="/" class="navbar-logo">
        <img src="/images/New_Logo_White.png" alt="Crysantem" class="navbar-logo-img">
        <span>CRYSANTEM</span>
      </a>
      <div class="navbar-auth">
        <button id="authBtn" class="navbar-auth-btn">Account</button>
        <div id="authDropdown" class="navbar-dropdown">
          <button id="logoutBtn" class="navbar-dropdown-item navbar-dropdown-logout">Cerrar sesión</button>
        </div>
      </div>
    </div>
  </nav>

  <div class="container" style="padding-top: 100px;">
    <div class="header">
      ${config.logo_url ? `<img src="${config.logo_url}" class="logo">` : ''}
      <h1>${config.business_name || 'Mi Negocio'}</h1>
    </div>

    <div class="content"></div>

    <div class="chat-section">
      <div class="chat-wrapper">
        <div class="chat">
          <div class="chat-header"><div class="chat-status"></div><span>Asistente Virtual</span></div>
          <div class="chat-messages"><div class="chat-bubble ai">${config.welcome_message || 'Hola, ¿en qué puedo ayudarte?'}</div></div>
          <div class="chat-input"><input type="text" placeholder="Escribe tu mensaje..."><button>Enviar</button></div>
        </div>
      </div>
    </div>

    ${config.show_footer !== false ? `
    <div class="footer">
      Powered by Crysantem Intelligence
      ${socialLinksHTML ? `<div class="social-links">${socialLinksHTML}</div>` : ''}
    </div>
    ` : ''}
  </div>

  <div id="authModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title">Iniciar Sesión</h3>
        <button class="modal-close">×</button>
      </div>
      <form id="authForm"></form>
    </div>
  </div>

  <script src="/js/myia-auth.js"></script>
  <script>
    const chatInput = document.querySelector('.chat-input input');
    const chatButton = document.querySelector('.chat-input button');
    const chatMessages = document.querySelector('.chat-messages');

    // Datos seguros (sin webhooks expuestos)
    const pageId = '${config.id}';
    const userId = '${config.user_id}';
    const plan = '${config.plan}';

    console.log('Page ID:', pageId);
    console.log('User ID:', userId);
    console.log('Plan:', plan);

    if (chatInput && chatButton) {
      chatInput.disabled = false;
      chatButton.disabled = false;

      chatButton.addEventListener('click', sendMessage);
      chatInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') sendMessage(); });

      async function sendMessage() {
        const message = chatInput.value.trim();
        if (!message) return;

        addMessage(message, 'user');
        chatInput.value = '';
        chatInput.disabled = true;
        chatButton.disabled = true;

        try {
          // Enviar al proxy del backend (seguro - webhooks solo en backend)
          const response = await fetch('/api/myia/chat-message', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              message,
              pageId,
              userId,
              plan
            })
          });

          const data = await response.json();

          if (response.ok && data.success && data.response) {
            addMessage(data.response, 'ai');
          } else {
            addMessage('Lo siento, hubo un error al procesar tu mensaje. Por favor intenta nuevamente.', 'ai');
          }
        } catch (error) {
          console.error('Error sending message:', error);
          addMessage('Lo siento, no pudimos conectar con el servicio. Por favor intenta nuevamente.', 'ai');
        } finally {
          chatInput.disabled = false;
          chatButton.disabled = false;
          chatInput.focus();
        }
      }

      function addMessage(text, type) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'chat-bubble';
        messageDiv.classList.add(type);
        messageDiv.innerHTML = type === 'ai' ? marked.parse(text) : text;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
      }
    }
  </script>
</body>
</html>`;
}

// Endpoint para ver logs (solo para debugging)
router.get('/debug-logs', (req, res) => {
  const fs = require('fs');
  const path = require('path');
  const logFile = path.join(__dirname, '../debug-config.log');
  
  try {
    const logs = fs.readFileSync(logFile, 'utf8');
    res.json({ success: true, logs });
  } catch (error) {
    res.json({ success: true, logs: 'No hay logs aún' });
  }
});

// Endpoint simple para verificar que myia router funciona
router.get('/test', (req, res) => {
  res.json({ success: true, message: 'MyIA router funciona' });
});

module.exports = router;
