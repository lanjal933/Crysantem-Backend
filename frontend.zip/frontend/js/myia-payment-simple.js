// Configuración de planes
const PLAN_PRICES = {
  responde: {
    name: '01 - Responde',
    implementation: '$0',
    monthly: '$0',
    aiModel: 'Gemini Flash',
    tokenLimit: '10,000/mes'
  },
  asiste: {
    name: '02 - Asiste',
    implementation: '$99',
    monthly: '$49/mes',
    aiModel: 'Gemini Flash',
    tokenLimit: '50,000/mes'
  },
  automatiza: {
    name: '03 - Automatiza',
    implementation: '$199',
    monthly: '$99/mes',
    aiModel: 'Gemini Pro',
    tokenLimit: '100,000/mes'
  },
  intelligence: {
    name: '04 - Crysantem Intelligence',
    implementation: '$399',
    monthly: '$199/mes',
    aiModel: 'Gemini Pro',
    tokenLimit: '∞'
  }
};

document.addEventListener('DOMContentLoaded', () => {
  console.log('=== CARGANDO PÁGINA DE PAGO ===');
  
  // Obtener el plan seleccionado
  const plan = localStorage.getItem('selectedPlan');
  
  if (!plan) {
    console.error('No hay plan seleccionado');
    alert('Error: No hay plan seleccionado. Por favor regresa a la selección de planes.');
    window.location.href = 'myia-plans.html';
    return;
  }
  
  console.log('Plan seleccionado:', plan);
  
  // Mostrar información del plan
  const planInfo = PLAN_PRICES[plan];
  
  if (planInfo) {
    document.getElementById('planName').textContent = planInfo.name;
    document.getElementById('implementationPrice').textContent = planInfo.implementation;
    document.getElementById('monthlyPrice').textContent = planInfo.monthly;
    document.getElementById('aiModel').textContent = planInfo.aiModel;
    document.getElementById('tokenLimit').textContent = planInfo.tokenLimit;
  }
  
  // Event listener para el botón de Mercado Pago
  document.getElementById('mercadopagoBtn').addEventListener('click', () => {
    console.log('Botón de pago clickeado, redirigiendo a OAuth');
    // Redirigir a la página de OAuth
    window.location.href = 'myia-oauth.html';
  });
});
