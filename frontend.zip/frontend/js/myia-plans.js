let selectedPlan = null;
const planConfig = {
  responde: {
    aiModel: 'gemini-flash',
    characterLimit: 50000,
    setupPrice: 112000,
    monthlyPrice: 22500,
    scopes: ['email', 'profile']
  },
  asiste: {
    aiModel: 'gemini-flash',
    characterLimit: 100000,
    setupPrice: 225000,
    monthlyPrice: 22500,
    scopes: ['email', 'profile', 'https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive.readonly']
  },
  automatiza: {
    aiModel: 'gemini-pro',
    characterLimit: 500000,
    setupPrice: 375000,
    monthlyPrice: 32000,
    scopes: ['email', 'profile', 'https://www.googleapis.com/auth/calendar']
  },
  intelligence: {
    aiModel: 'gemini-pro',
    characterLimit: 2000000,
    setupPrice: 600000,
    monthlyPrice: 32000,
    scopes: ['email', 'profile', 'https://www.googleapis.com/auth/calendar', 'https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive.readonly', 'https://www.googleapis.com/auth/gmail.readonly']
  }
};

function selectPlan(plan) {
  selectedPlan = plan;
  
  // Actualizar UI
  document.querySelectorAll('.plan-card').forEach(card => {
    card.classList.remove('selected');
  });
  document.querySelector(`[data-plan="${plan}"]`).classList.add('selected');
  
  // Habilitar botón continuar
  document.getElementById('continueBtn').disabled = false;
}

async function continueToDesign() {
  if (!selectedPlan) return;

  // Guardar plan seleccionado
  localStorage.setItem('selectedPlan', selectedPlan);
  localStorage.setItem('planConfig', JSON.stringify(planConfig[selectedPlan]));

  // Limpiar flag de coworker (flujo normal)
  localStorage.removeItem('coworkerSkipOAuth');
  localStorage.removeItem('isCoworker');

  console.log('Flujo normal iniciado - coworkerSkipOAuth limpiado');

  // Redirigir al constructor (myia-builder.html)
  window.location.href = 'myia-builder.html';
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
  // Agregar listeners a las tarjetas de planes
  document.querySelectorAll('.plan-card').forEach(card => {
    card.addEventListener('click', () => {
      selectPlan(card.dataset.plan);
    });
  });

  // Listener para el botón continuar
  const continueBtn = document.getElementById('continueBtn');
  if (continueBtn) {
    continueBtn.addEventListener('click', continueToDesign);
  }

  // Listener para el botón volver
  const backBtn = document.getElementById('backBtn');
  if (backBtn) {
    backBtn.addEventListener('click', () => {
      window.location.href = 'myia-home.html';
    });
  }
});
